-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3307
-- Généré le : ven. 12 mars 2021 à 15:30
-- Version du serveur :  10.4.13-MariaDB
-- Version de PHP : 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `election`
--

-- --------------------------------------------------------

--
-- Structure de la table `election`
--

DROP TABLE IF EXISTS `election`;
CREATE TABLE IF NOT EXISTS `election` (
  `IdElection` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(150) NOT NULL,
  PRIMARY KEY (`IdElection`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Structure de la table `participation`
--

DROP TABLE IF EXISTS `participation`;
CREATE TABLE IF NOT EXISTS `participation` (
  `IdUser` int(11) NOT NULL,
  `IdElection` int(11) NOT NULL,
  PRIMARY KEY (`IdUser`,`IdElection`),
  KEY `IdElection` (`IdElection`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

DROP TABLE IF EXISTS `role`;
CREATE TABLE IF NOT EXISTS `role` (
  `IdRole` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(22) NOT NULL,
  PRIMARY KEY (`IdRole`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `role`
--

INSERT INTO `role` (`IdRole`, `Description`) VALUES
(1, 'Organisateur');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `idUser` int(11) NOT NULL AUTO_INCREMENT,
  `LastName` varchar(22) NOT NULL,
  `FirstName` varchar(22) NOT NULL,
  `Password` char(60) NOT NULL,
  `email` varchar(50) NOT NULL,
  `IdRole` int(11) NOT NULL,
  PRIMARY KEY (`idUser`),
  UNIQUE KEY `email` (`email`),
  KEY `IdRole` (`IdRole`),
  KEY `Password` (`Password`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`idUser`, `LastName`, `FirstName`, `Password`, `email`, `IdRole`) VALUES
(17, 'test3', 'test3', '$2y$10$e6WiBEhb/Gy27VRi1G14BOynDBY.mdZ38cAZBzYnovCNBhzeAd7sK', 'test3@test.fr', 1),
(18, 'test4', 'test4', '$2y$10$qeL01Qod6fS2vqwbL6SBRe1gZReqBBhByhIAOMM1t1D/fpmWRO7oe', 'test4@test.fr', 1),
(19, 'test5', 'test5', '$2y$10$6WvfKahYXb6tv8APSkPffOdJuJZGTIglOcvxG2QM.OtHuDTzN1VP6', 'test5@test.fr', 1),
(20, 'test6', 'test6', '$2y$10$Qgfuiw4nkHV3g7KviCr18ObNEwck8zqCqBGMKQyp0gxZZamsQnJKm', 'test6@test.fr', 1),
(21, 'test7', 'test7', '$2y$10$IqEK4e5FNKoPXrJq6D/WmeZ7nFUh6JVAQbxd7QDst3d1v2Y2QIM4W', 'test7@test.fr', 1),
(22, 'test8', 'test8', '$2y$10$KY7gjlfvEh6vceJe9veM2O1ePQVXMF2oSmojkvY.O/nDhdAYd0rX.', 'test8@test.fr', 1),
(23, 'test9', 'test9', '$2y$10$BpuREYpxvRAYnf0o34YciOG5yQhdrobhL.6OxsgtfQKyYWz0xh2uO', 'test9@test.fr', 1);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
